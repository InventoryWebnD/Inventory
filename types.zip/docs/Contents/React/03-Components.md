# Components

## Introduction

Components are reusable pieces of UI. Good React applications break a screen into components with clear responsibilities instead of placing all markup and logic in one file.

> **WebnD Inventory Focus:** This file is designed for practical React evaluation. A student should be able to explain the concept, recognize incorrect implementations, and use it inside a small working React feature.

## Subtopics

- Functional components
- Component naming
- Reusable components
- Parent/child hierarchy
- Component composition
- Nested components
- UI decomposition
- Presentational vs logic-heavy components
- Component boundaries
- Reusability

## Syntax / Core Pattern

```jsx
function ProductCard({ product }) {
  return (
    <article className="product-card">
      <h3>{product.name}</h3>
      <p>₹{product.price}</p>
    </article>
  );
}

function ProductList({ products }) {
  return products.map(product => (
    <ProductCard key={product.id} product={product} />
  ));
}
```

## Important Concepts

| Topic | Purpose | Example |
|---|---|---|
| Component | Reusable UI unit | `Navbar`, `ProductCard` |
| Composition | Building larger UI from smaller components | `Dashboard` contains `Sidebar` and `Main` |
| Hierarchy | Parent/child structure | `App → Products → ProductCard` |
| Responsibility | What a component should own | A modal owns modal presentation/state |

## Common Use Cases

- **Beginner:** Navbar, sidebar, product card and footer as separate units.
- **Practical UI:** Reusable table, modal and button components across multiple pages.
- **Real-world:** Page-level components composed from smaller feature components.

## Common Errors

1. ❌ **Lowercase custom component**

```jsx
`<productCard />`
```
**Why it is a problem:** React treats lowercase tags as DOM elements; use `ProductCard`.

2. ❌ **One giant component**

```jsx
Hundreds of lines in `App.jsx`
```
**Why it is a problem:** Split by responsibility and reusable UI.

3. ❌ **Duplicating markup**

```jsx
Copying the same card five times
```
**Why it is a problem:** Create a component and render data with `map`.

## Common Mistakes

- Creating components only for the sake of splitting files.
- Giving every tiny `<div>` its own component without a reason.
- Coupling reusable components to one specific dataset.

## Quick Reference

```text
App
├── Navbar
├── Dashboard
│   ├── Filters
│   ├── Stats
│   └── ProductList
│       └── ProductCard
└── Footer
```

## Inventory Checkpoints

A strong candidate should be able to:

1. **Explain** the concept in simple words.
2. **Write** a working implementation without blindly copying a tutorial.
3. **Debug** at least one common mistake.
4. **Combine** this topic with previously learned React concepts.
5. **Recognize** when the concept should *not* be used.

## Practical Challenge Ideas

- Build a small feature using this topic from scratch.
- Modify an existing component so the topic becomes necessary.
- Debug a deliberately broken implementation.
- Combine this topic with state, props, events and API data where appropriate.
