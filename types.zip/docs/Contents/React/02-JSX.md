# JSX

## Introduction

JSX is a syntax extension that lets JavaScript code describe UI using an HTML-like notation. JSX is not HTML: attributes, expressions, component names and JavaScript control flow follow JavaScript/React rules.

> **WebnD Inventory Focus:** This file is designed for practical React evaluation. A student should be able to explain the concept, recognize incorrect implementations, and use it inside a small working React feature.

## Subtopics

- JSX expressions
- `className` and `htmlFor`
- Self-closing elements
- JavaScript inside `{}`
- Fragments
- Conditional expressions
- Dynamic attributes
- Inline styles
- JSX comments
- Nested JSX
- Rendering variables and objects

## Syntax / Core Pattern

```jsx
const user = { name: "Lakshya", active: true };

function Profile() {
  return (
    <>
      <h2>{user.name}</h2>
      <p className={user.active ? "active" : "inactive"}>
        {user.active ? "Active" : "Inactive"}
      </p>
      <img src="/avatar.png" alt={`${user.name}'s avatar`} />
    </>
  );
}
```

## Important Concepts

| Topic | Purpose | Example |
|---|---|---|
| `className` | CSS class | `className="card"` |
| `{}` | JavaScript expression | `{price * quantity}` |
| Fragment | Group elements without extra DOM node | `<>...</>` |
| `style` | JavaScript object of styles | `style={{ marginTop: 12 }}` |
| Component tag | Render a React component | `<ProductCard />` |

## Common Use Cases

- **Beginner:** Rendering API data in a card.
- **Practical UI:** Showing different labels based on state.
- **Real-world:** Generating accessible attributes dynamically.

## Common Errors

1. ❌ **Using `class`**

```jsx
`<div class="box">`
```
**Why it is a problem:** Use `className`.

2. ❌ **Multiple root elements**

```jsx
Returning sibling JSX without a wrapper
```
**Why it is a problem:** Wrap in a parent or Fragment.

3. ❌ **Statements inside JSX**

```jsx
Trying to put `if (...)` directly inside `{}`
```
**Why it is a problem:** Use a helper, ternary, `&&`, or calculate before `return`.

4. ❌ **Wrong style syntax**

```jsx
`style="color:red"`
```
**Why it is a problem:** Use an object: `style={{ color: "red" }}`.

## Common Mistakes

- Treating JSX as literal HTML.
- Forgetting to escape JavaScript expressions correctly.
- Overusing nested ternaries until JSX becomes unreadable.

## Quick Reference

```jsx
return (
  <>
    <h1>{title}</h1>
    {items.length > 0 ? <List /> : <EmptyState />}
  </>
);
```

## Inventory Checkpoints

A strong candidate should be able to:

1. **Explain** the concept in simple words.
2. **Write** a working implementation without blindly copying a tutorial.
3. **Debug** at least one common mistake.
4. **Combine** this topic with previously learned React concepts.
5. **Recognize** when the concept should *not* be used.

## Practical Challenge Ideas

- Build a small feature using this topic from scratch.
- Modify an existing component so the topic becomes necessary.
- Debug a deliberately broken implementation.
- Combine this topic with state, props, events and API data where appropriate.
