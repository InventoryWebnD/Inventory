# Conditional Rendering

## Introduction

Conditional rendering means choosing which UI to display based on current state, props or data. It is fundamental for loading screens, authentication, empty states, errors and feature flags.

> **WebnD Inventory Focus:** This file is designed for practical React evaluation. A student should be able to explain the concept, recognize incorrect implementations, and use it inside a small working React feature.

## Subtopics

- `if` statements
- Ternary operator
- Logical `&&`
- Early returns
- Loading/error/empty states
- Conditional components
- Nested conditions
- Null rendering

## Syntax / Core Pattern

```jsx
if (loading) return <Spinner />;
if (error) return <ErrorState message={error} />;

return (
  <>
    {items.length === 0 ? (
      <EmptyState />
    ) : (
      <ProductList items={items} />
    )}

    {isAdmin && <AdminTools />}
  </>
);
```

## Important Concepts

| Topic | Purpose | Example |
|---|---|---|
| Early return | Exit component for a state | `if (loading) return <Spinner />` |
| Ternary | Choose between two UI branches | `isOpen ? <Panel/> : null` |
| `&&` | Render when condition is truthy | `isAdmin && <Admin />` |

## Common Use Cases

- **Beginner:** Loading and error screens.
- **Practical UI:** Login vs dashboard.
- **Real-world:** Empty search results.

## Common Errors

1. ❌ **Falsy numeric rendering**

```jsx
`count && <Badge />` when count is `0`
```
**Why it is a problem:** Use `count > 0 && ...`.

2. ❌ **Deep nested ternaries**

```jsx
Multiple `? :` chains
```
**Why it is a problem:** Use variables, helper components or early returns.

3. ❌ **Checking the wrong state**

```jsx
Using stale/derived flags
```
**Why it is a problem:** Keep conditions tied to the source of truth.

## Common Mistakes

- Using CSS to hide UI when the component should not exist.
- Making conditions so complex that they are unreadable.
- Forgetting the empty state.

## Quick Reference

```jsx
if (loading) return <Loader />;
if (error) return <Error />;
if (!items.length) return <Empty />;
return <Content />;
```

## Inventory Checkpoints

A strong candidate should be able to:

1. **Explain** the concept in simple words.
2. **Write** a working implementation without blindly copying a tutorial.
3. **Debug** at least one common mistake.
4. **Combine** this topic with previously learned React concepts.
5. **Recognize** when the concept should *not* be used.

## Practical Challenge Ideas

- Build a small feature using this topic from scratch.
- Modify an existing component so the topic becomes necessary.
- Debug a deliberately broken implementation.
- Combine this topic with state, props, events and API data where appropriate.
