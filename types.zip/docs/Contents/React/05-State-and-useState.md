# State and `useState`

## Introduction

State is component-owned data whose changes can trigger a re-render. `useState` is the standard Hook for local interactive state.

> **WebnD Inventory Focus:** This file is designed for practical React evaluation. A student should be able to explain the concept, recognize incorrect implementations, and use it inside a small working React feature.

## Subtopics

- `useState`
- State initialization
- Updating state
- Previous state
- Multiple state variables
- Objects and arrays in state
- Immutability
- Functional updates
- Derived values
- State batching

## Syntax / Core Pattern

```jsx
import { useState } from "react";

function Cart() {
  const [count, setCount] = useState(0);

  function addOne() {
    setCount(previous => previous + 1);
  }

  return <button onClick={addOne}>Cart: {count}</button>;
}
```

Updating an object:

```jsx
setUser(previous => ({ ...previous, name: "Aman" }));
```

Updating an array:

```jsx
setItems(previous => [...previous, newItem]);
```

## Important Concepts

| Topic | Purpose | Example |
|---|---|---|
| `useState(initial)` | Creates a state value and setter | `const [open, setOpen] = useState(false)` |
| Functional update | Use previous state safely | `setCount(c => c + 1)` |
| Spread | Create a new object/array | `setUser(u => ({...u, age: 20}))` |

## Common Use Cases

- **Beginner:** Modal open/close state.
- **Practical UI:** Shopping-cart count and selected items.
- **Real-world:** Search/filter state in a dashboard.

## Common Errors

1. ❌ **Direct mutation**

```jsx
`items.push(newItem)`
```
**Why it is a problem:** Create a new array and set it.

2. ❌ **Stale value in repeated updates**

```jsx
`setCount(count + 1)` three times
```
**Why it is a problem:** Use functional updates when updates depend on previous state.

3. ❌ **Duplicated derived state**

```jsx
Store `total` separately when it is fully determined by items
```
**Why it is a problem:** Calculate derived values during render when practical.

## Common Mistakes

- Expecting state setters to return the new state.
- Using state for values that never affect UI.
- Keeping multiple pieces of state that should always change together.

## Quick Reference

```jsx
const [value, setValue] = useState(initialValue);
setValue(nextValue);
setValue(previous => computeFrom(previous));
```

## Inventory Checkpoints

A strong candidate should be able to:

1. **Explain** the concept in simple words.
2. **Write** a working implementation without blindly copying a tutorial.
3. **Debug** at least one common mistake.
4. **Combine** this topic with previously learned React concepts.
5. **Recognize** when the concept should *not* be used.

## Practical Challenge Ideas

- Build a small feature using this topic from scratch.
- Modify an existing component so the topic becomes necessary.
- Debug a deliberately broken implementation.
- Combine this topic with state, props, events and API data where appropriate.
