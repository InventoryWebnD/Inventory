# Events and Event Handling

## Introduction

React handles browser interactions through event props such as `onClick`, `onChange` and `onSubmit`. Event handlers should update state or call business logic rather than directly manipulating the DOM.

> **WebnD Inventory Focus:** This file is designed for practical React evaluation. A student should be able to explain the concept, recognize incorrect implementations, and use it inside a small working React feature.

## Subtopics

- `onClick`
- `onChange`
- `onSubmit`
- Keyboard events
- Mouse events
- Synthetic events
- Passing arguments
- `preventDefault`
- Event propagation
- Event bubbling

## Syntax / Core Pattern

```jsx
function SearchBox({ value, onChange }) {
  return (
    <input
      value={value}
      onChange={event => onChange(event.target.value)}
      onKeyDown={event => {
        if (event.key === "Enter") console.log("Search");
      }}
    />
  );
}

function Form() {
  function handleSubmit(event) {
    event.preventDefault();
    // submit data
  }

  return <form onSubmit={handleSubmit}>...</form>;
}
```

## Important Concepts

| Topic | Purpose | Example |
|---|---|---|
| Event prop | React event handler prop | `onClick={handleClick}` |
| Event object | Information about the event | `event.target.value` |
| `preventDefault` | Stops default browser action | Prevent form navigation |
| Propagation | Event travels through DOM tree | Bubbling to parent handlers |

## Common Use Cases

- **Beginner:** Buttons that modify state.
- **Practical UI:** Search input that updates results.
- **Real-world:** Forms that validate before submission.

## Common Errors

1. ❌ **Calling handler during render**

```jsx
`onClick={handleClick()}`
```
**Why it is a problem:** This executes immediately; pass the function.

2. ❌ **Forgetting `preventDefault`**

```jsx
Form reloads page
```
**Why it is a problem:** Call it when intercepting normal form submission.

3. ❌ **Reading wrong target**

```jsx
`event.value`
```
**Why it is a problem:** For inputs, use `event.target.value`.

## Common Mistakes

- Putting huge business logic directly inside JSX handlers.
- Using `onClick` on non-interactive elements when a button would be more accessible.
- Forgetting keyboard accessibility for custom controls.

## Quick Reference

```jsx
<button onClick={handleClick}>Save</button>
<input onChange={handleChange} />
<form onSubmit={handleSubmit}>...</form>
```

## Inventory Checkpoints

A strong candidate should be able to:

1. **Explain** the concept in simple words.
2. **Write** a working implementation without blindly copying a tutorial.
3. **Debug** at least one common mistake.
4. **Combine** this topic with previously learned React concepts.
5. **Recognize** when the concept should *not* be used.

## Practical Challenge Ideas

- Build a small feature using this topic from scratch.
- Modify an existing component so the topic becomes necessary.
- Debug a deliberately broken implementation.
- Combine this topic with state, props, events and API data where appropriate.
