# Props

## Introduction

Props are inputs passed from a parent component to a child. They are the main mechanism for configuring reusable components and represent one-way data flow from parent to child.

> **WebnD Inventory Focus:** This file is designed for practical React evaluation. A student should be able to explain the concept, recognize incorrect implementations, and use it inside a small working React feature.

## Subtopics

- Passing props
- Destructuring
- Strings/numbers/booleans
- Arrays and objects
- Function props
- `children`
- Props immutability
- One-way data flow
- Default values
- Prop-driven UI

## Syntax / Core Pattern

```jsx
function ProductCard({ product, onAddToCart, featured = false, children }) {
  return (
    <article>
      <h3>{product.name}</h3>
      {featured && <span>Featured</span>}
      {children}
      <button onClick={() => onAddToCart(product.id)}>
        Add
      </button>
    </article>
  );
}

<ProductCard
  product={product}
  featured={product.rating > 4.5}
  onAddToCart={handleAddToCart}
>
  <small>In stock</small>
</ProductCard>
```

## Important Concepts

| Topic | Purpose | Example |
|---|---|---|
| Scalar prop | String, number or boolean | `price={499}` |
| Object prop | Structured data | `product={product}` |
| Function prop | Child can request parent action | `onDelete={handleDelete}` |
| Children | Nested JSX passed to component | `<Card>...</Card>` |

## Common Use Cases

- **Beginner:** Reusable cards with different data.
- **Practical UI:** Buttons that trigger parent-owned actions.
- **Real-world:** Layout components accepting arbitrary children.

## Common Errors

1. ❌ **Mutating props**

```jsx
`props.product.price = 0`
```
**Why it is a problem:** Props should be treated as read-only; update the owner state instead.

2. ❌ **Forgetting braces**

```jsx
`count="count"`
```
**Why it is a problem:** Use `count={count}` for a JavaScript value.

3. ❌ **Passing an event result instead of handler**

```jsx
`onClick={handleClick()}`
```
**Why it is a problem:** Usually pass `onClick={handleClick}` or a callback when arguments are needed.

## Common Mistakes

- Using too many unrelated props.
- Passing entire application state when only one field is needed.
- Using props as if they were mutable local state.

## Quick Reference

```jsx
<Child
  title="Inventory"
  count={items.length}
  active={isOpen}
  onSelect={handleSelect}
/>
```

## Inventory Checkpoints

A strong candidate should be able to:

1. **Explain** the concept in simple words.
2. **Write** a working implementation without blindly copying a tutorial.
3. **Debug** at least one common mistake.
4. **Combine** this topic with previously learned React concepts.
5. **Recognize** when the concept should *not* be used.

## Practical Challenge Ideas

- Build a small feature using this topic from scratch.
- Modify an existing component so the topic becomes necessary.
- Debug a deliberately broken implementation.
- Combine this topic with state, props, events and API data where appropriate.
