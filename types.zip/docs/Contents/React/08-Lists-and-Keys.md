# Rendering Lists and Keys

## Introduction

React commonly renders collections with `map()`. Each sibling element in a list needs a stable `key` so React can correctly track identity across renders.

> **WebnD Inventory Focus:** This file is designed for practical React evaluation. A student should be able to explain the concept, recognize incorrect implementations, and use it inside a small working React feature.

## Subtopics

- `map()`
- `key` prop
- Stable unique keys
- Why indexes can be risky
- Nested lists
- Filtering before mapping
- Empty lists
- Dynamic insertion/deletion

## Syntax / Core Pattern

```jsx
function ProductList({ products }) {
  return (
    <ul>
      {products.map(product => (
        <li key={product.id}>
          {product.name} — ₹{product.price}
        </li>
      ))}
    </ul>
  );
}
```

## Important Concepts

| Topic | Purpose | Example |
|---|---|---|
| `map` | Transforms each data item into JSX | `items.map(item => <Card ... />)` |
| `key` | Stable identity for sibling elements | `key={item.id}` |
| Index key | Position used as identity | `key={index}`; safe only for truly static lists |

## Common Use Cases

- **Beginner:** Product cards from API data.
- **Practical UI:** Editable todo lists.
- **Real-world:** Table rows with add/delete/reorder behavior.

## Common Errors

1. ❌ **Missing key**

```jsx
React warning
```
**Why it is a problem:** Give each sibling a stable key.

2. ❌ **Random key**

```jsx
`key={Math.random()}`
```
**Why it is a problem:** Changes identity every render and defeats reconciliation.

3. ❌ **Index key on reorderable list**

```jsx
State/DOM can appear attached to wrong item
```
**Why it is a problem:** Use stable item IDs.

## Common Mistakes

- Using array index by default.
- Using duplicate IDs.
- Mapping data and then accidentally returning no element.

## Quick Reference

```jsx
{items.map(item => (
  <Component key={item.id} item={item} />
))}
```

## Inventory Checkpoints

A strong candidate should be able to:

1. **Explain** the concept in simple words.
2. **Write** a working implementation without blindly copying a tutorial.
3. **Debug** at least one common mistake.
4. **Combine** this topic with previously learned React concepts.
5. **Recognize** when the concept should *not* be used.

## Practical Challenge Ideas

- Build a small feature using this topic from scratch.
- Modify an existing component so the topic becomes necessary.
- Debug a deliberately broken implementation.
- Combine this topic with state, props, events and API data where appropriate.
