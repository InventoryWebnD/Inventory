# React Fundamentals

## Introduction

React is a JavaScript library for building user interfaces from reusable components. Instead of manually changing DOM nodes, you describe what the UI should look like for the current data and state, and React updates the interface when that data changes.

For the WebnD inventory, this topic should establish the mental model: **UI = function of data/state**, components form a tree, props flow downward, and state changes cause React to render again.

> **WebnD Inventory Focus:** This file is designed for practical React evaluation. A student should be able to explain the concept, recognize incorrect implementations, and use it inside a small working React feature.

## Subtopics

- What React is and why it is used
- Library vs framework
- Component-based UI
- Declarative UI
- Single Page Applications (SPA)
- React DOM and `createRoot`
- Virtual DOM and reconciliation concepts
- One-way data flow
- Rendering and re-rendering
- React project entry points
- Development vs production builds

## Syntax / Core Pattern

```jsx
import { createRoot } from "react-dom/client";
import App from "./App.jsx";

createRoot(document.getElementById("root")).render(<App />);
```

A minimal component:

```jsx
function App() {
  return <h1>WebnD Inventory</h1>;
}

export default App;
```

## Important Concepts

| Topic | Purpose | Example |
|---|---|---|
| Concept | Meaning | Example |
| React | UI library based on components | Build a dashboard from reusable components |
| Component | Reusable UI unit | `ProductCard` |
| Render | React produces UI from current inputs | `<App />` |
| State | Data owned by a component that can change | Cart count |
| Props | Data passed from parent to child | `<Card title="React" />` |

## Common Use Cases

- **Beginner:** A dashboard where cards, filters and tables are separate components.
- **Practical UI:** A single-page portfolio where navigation changes the displayed component without full-page reloads.
- **Real-world:** An inventory interface where changing stock state automatically updates badges, totals and buttons.

## Common Errors

1. ❌ **Direct DOM manipulation**

```jsx
document.querySelector(...).textContent = ...
```
**Why it is a problem:** React should normally derive the DOM from state/props instead.

2. ❌ **Calling a component like a normal function**

```jsx
`App()` inside JSX
```
**Why it is a problem:** Use `<App />`; component identity matters to React.

3. ❌ **Putting changing data in ordinary variables**

```jsx
`let count = 0`
```
**Why it is a problem:** Use state when a change must trigger a UI update.

4. ❌ **Expecting a render to mutate the DOM immediately**

```jsx
Assuming state assignment instantly changes DOM
```
**Why it is a problem:** React schedules and commits updates; reason in terms of state -> render -> commit.

## Common Mistakes

- Thinking React is HTML with a few special tags.
- Mixing imperative DOM manipulation with React unnecessarily.
- Storing UI-changing data in normal variables.
- Building one giant component instead of a component tree.

## Quick Reference

```text
Data / State
    ↓
Component render
    ↓
React reconciliation
    ↓
DOM commit
    ↓
Browser displays UI
```

## Inventory Checkpoints

A strong candidate should be able to:

1. **Explain** the concept in simple words.
2. **Write** a working implementation without blindly copying a tutorial.
3. **Debug** at least one common mistake.
4. **Combine** this topic with previously learned React concepts.
5. **Recognize** when the concept should *not* be used.

## Practical Challenge Ideas

- Build a small feature using this topic from scratch.
- Modify an existing component so the topic becomes necessary.
- Debug a deliberately broken implementation.
- Combine this topic with state, props, events and API data where appropriate.
