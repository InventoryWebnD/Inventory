"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef } from "react";

export interface CubeFace {
  label: string;
  href: string;
}

interface HeroCubeProps {
  /** Up to 6 faces. Each face is a link to a topic. */
  faces: CubeFace[];
}

/**
 * Interactive 3D cube.
 *  - NO auto-rotation.
 *  - Move the mouse over it (hover) and it rotates with the cursor, with a bit of inertia.
 *  - Press & drag (mouse or touch) to spin it harder.
 *  - Arrow keys rotate it when focused.
 */
export default function HeroCube({ faces }: HeroCubeProps) {
  const sceneRef = useRef<HTMLDivElement>(null);
  const cubeRef = useRef<HTMLDivElement>(null);
  const s = useRef({
    rx: -24,
    ry: 35,
    vx: 0,
    vy: 0,
    lastX: 0,
    lastY: 0,
    hasLast: false,
    downX: 0,
    downY: 0,
    moved: 0,
    raf: 0,
  });

  const paint = useCallback(() => {
    const { rx, ry } = s.current;
    if (cubeRef.current) {
      cubeRef.current.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`;
    }
  }, []);

  const step = useCallback(() => {
    const st = s.current;
    st.ry += st.vx;
    st.rx += st.vy;
    st.vx *= 0.9;
    st.vy *= 0.9;
    paint();
    if (Math.abs(st.vx) > 0.02 || Math.abs(st.vy) > 0.02) {
      st.raf = requestAnimationFrame(step);
    } else {
      st.raf = 0;
    }
  }, [paint]);

  const kick = useCallback(
    (dvx: number, dvy: number) => {
      const st = s.current;
      st.vx = Math.max(-30, Math.min(30, st.vx + dvx));
      st.vy = Math.max(-30, Math.min(30, st.vy + dvy));
      if (!st.raf) st.raf = requestAnimationFrame(step);
    },
    [step]
  );

  useEffect(() => {
    paint();
    const st = s.current;
    return () => {
      if (st.raf) cancelAnimationFrame(st.raf);
    };
  }, [paint]);

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const st = s.current;
    if (e.buttons) {
      st.moved = Math.max(st.moved, Math.hypot(e.clientX - st.downX, e.clientY - st.downY));
    }
    if (st.hasLast) {
      const dx = e.clientX - st.lastX;
      const dy = e.clientY - st.lastY;
      // dragging spins a little harder than plain hovering
      const gain = e.buttons ? 0.22 : 0.15;
      kick(dx * gain, -dy * gain);
    }
    st.lastX = e.clientX;
    st.lastY = e.clientY;
    st.hasLast = true;
  };

  const onPointerEnter = (e: React.PointerEvent<HTMLDivElement>) => {
    const st = s.current;
    st.lastX = e.clientX;
    st.lastY = e.clientY;
    st.hasLast = true;
  };

  const onPointerLeave = () => {
    s.current.hasLast = false;
    sceneRef.current?.classList.remove("is-dragging");
  };

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    s.current.lastX = e.clientX;
    s.current.lastY = e.clientY;
    s.current.hasLast = true;
    s.current.downX = e.clientX;
    s.current.downY = e.clientY;
    s.current.moved = 0;
    sceneRef.current?.classList.add("is-dragging");
  };

  // A drag must not count as a click on a face.
  const onClickCapture = (e: React.MouseEvent<HTMLDivElement>) => {
    if (s.current.moved > 6) {
      e.preventDefault();
      e.stopPropagation();
    }
  };

  const onPointerUp = () => {
    sceneRef.current?.classList.remove("is-dragging");
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    const k = e.key;
    if (k === "ArrowLeft") kick(-6, 0);
    else if (k === "ArrowRight") kick(6, 0);
    else if (k === "ArrowUp") kick(0, 6);
    else if (k === "ArrowDown") kick(0, -6);
    else return;
    e.preventDefault();
  };

  return (
    <div className="cube-wrap">
      <div
        ref={sceneRef}
        className="cube-scene"
        role="group"
        aria-label="Interactive 3D cube. Move your mouse over it or drag to rotate, click a face to open that topic."
        onPointerEnter={onPointerEnter}
        onPointerMove={onPointerMove}
        onPointerLeave={onPointerLeave}
        onPointerDown={onPointerDown}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onKeyDown={onKeyDown}
        onClickCapture={onClickCapture}
      >
        <div ref={cubeRef} className="cube">
          {faces.slice(0, 6).map((face, i) => (
            <Link
              key={`${face.href}-${i}`}
              href={face.href}
              draggable={false}
              aria-label={`Open ${face.label}`}
              className="cube-face"
            >
              <span>{face.label}</span>
            </Link>
          ))}
        </div>
      </div>
      <div className="cube-shadow" aria-hidden="true" />
      <span className="cube-hint">Spin it · click a face to open</span>
    </div>
  );
}
